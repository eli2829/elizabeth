body {
    font-family: Arial, sans-serif;
    margin: 20px;
    background-color: pink; /* Fondo rosa */
}

header, footer {
    text-align: center;
    margin: 20px 0;
}

table {
    width: 100%;
    border-collapse: collapse;
}

table, th, td {
    border: 1px solid black;
}

th, td {
    padding: 10px;
    text-align: left;
}

textarea {
    width: 100%;
    height: 100px;
}
